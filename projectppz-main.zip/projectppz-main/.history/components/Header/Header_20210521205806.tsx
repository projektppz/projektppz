import React from 'react'
import styled from 'styled-components'

const Wrapper = styled.header`
  .baner{
    
  }
`

export const Header = () => {
  return (
    <Wrapper>
      <div className="baner">
        DOJEBANY BANER
      </div>
    </Wrapper>
  )
}
