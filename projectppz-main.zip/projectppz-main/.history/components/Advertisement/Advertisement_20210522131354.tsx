import React from 'react'

export const Advertisement = () => {
  return (
    <div>
      
    </div>
  )
}
