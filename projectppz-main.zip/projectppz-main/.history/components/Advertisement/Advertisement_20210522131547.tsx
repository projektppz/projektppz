import React from 'react'
import styled from 'styled-components'

export const Advertisement = () => {
  return (
    <div>
      
    </div>
  )
}
