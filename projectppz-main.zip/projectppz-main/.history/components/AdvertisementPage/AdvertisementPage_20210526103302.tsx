import React from 'react';
import styled from 'styled-components';

const categoriesData = [
  {}
]

const Wrapper = styled.div`

`

export const AdvertisementPage = () => {
  return (
    <Wrapper>
      <div className="categories">

      </div>
    </Wrapper>
  )
};
