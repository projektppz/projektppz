import React from 'react'

export const AdvertisementPage = () => {
  return (
    <div>
      
    </div>
  )
}
