import React from 'react';
import styled from 'styled-components';
import { Input } from '../common/Input';

const Wrapper = styled.div``;

export const AddAdvertisementPage = () => {
  return <Wrapper>
    
  </Wrapper>;
};
