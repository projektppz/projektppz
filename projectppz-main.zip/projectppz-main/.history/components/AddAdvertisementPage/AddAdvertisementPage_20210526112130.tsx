import React from 'react'

export const AddAdvertisementPage = () => {
  return (
    <div>
      d
    </div>
  )
}
