import React from 'react'
import styled from 'styled-components';

const Wrapper = styled.

export const AddAdvertisementPage = () => {
  return (
    <div>
      d
    </div>
  )
}
