import React from 'react'

export const AddAdvertisementPage = () => {
  return (
    <div>
      
    </div>
  )
}
