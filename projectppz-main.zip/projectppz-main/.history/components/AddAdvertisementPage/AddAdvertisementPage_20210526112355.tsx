import React from 'react'
import styled from 's'

export const AddAdvertisementPage = () => {
  return (
    <div>
      d
    </div>
  )
}
